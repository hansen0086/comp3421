This library is being written as part of the Computer Graphics course at UNSW.

If you wish to fork it to work on assignments, please ensure that you fork it into a **private** repository. GitHub offers free private repositories as part of it's student developer pack, available [here](https://education.github.com/pack).

The project is set up as an eclipse project, so can be imported via the import option *Existing Projects into Workspace*.

## Releases

| Version | What                | Features                   | Zip file |
| ------- | ------------------- | -------------------------- |--------- |
| 0.1     | Week 1 starter code | Dots, dots and more dots.  | [v0.1.zip](https://github.com/robeverest/UNSWgraph/archive/v0.1.zip) |

## Additional notes

As it is intended for educational purposes, this library is missing many desirable features and optimisations. It prioritises clarity and simplicity over all other considerations.